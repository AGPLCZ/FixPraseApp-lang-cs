/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */

function maplibreMap() {

    var theme = "light";
    if (!inStorage("mapsource") || getStorage("mapsource") == "auto") {
        theme = "light";
        if ($("body").hasClass("theme-dark")) {
            theme = "dark";
        }
    } else {
        theme = getStorage("mapsource");
    }

    $("#mapbox").css("background-color", SETTINGS.maptileurls[theme].bgcolor);

    var map = new maplibregl.Map({
        container: 'mapbox',
        style: SETTINGS.maptileurls[theme].json,
        //attributionControl: false,
        interactive: true,
        pitch: 0,
        zoom: 1,
        maxZoom: 20,
        continuousWorld: false,
        noWrap: true,
        center: [-97, 38]
    });

    map.on('click', function (e) {
        var coordinates = e.lngLat;
        try {
            var latitude = (Math.round(coordinates.lat * 10000) / 10000);
            var longitude = (Math.round(coordinates.lng * 10000) / 10000);
            lookupAndShowCoords(latitude, longitude);
        } catch (ex) {
            alert(ex);
        }
    });

    map.addControl(new maplibregl.NavigationControl({
        visualizePitch: true
    }), 'top-left');

    map.addControl(new maplibregl.GeolocateControl({
        positionOptions: {
            enableHighAccuracy: true,
            timeout: 10 * 1000
        },
        fitBoundsOptions: {
            maxZoom: 16
        },
        trackUserLocation: true
    }), 'top-left');

    if (getStorage("mapscale") != "false") {
        map.addControl(
                new maplibregl.ScaleControl({
                    unit: getStorage("units") == "imperial" ? "imperial" : "metric"
                })
                );
    }

    map.mapEasing = function (t) {
        return t * (2 - t);
    };

    map.setMapHeading = function (heading) {
        if (typeof heading == 'number') {
            map.easeTo({
                bearing: heading,
                easing: map.mapEasing
            });
        }
    };

    map.setMapLocation = function (latitude, longitude) {
        map.easeTo({
            center: [
                longitude,
                latitude
            ]
        });
    };

    map.animateMapIn = function (latitude, longitude, zoom, heading) {
        if (typeof zoom == 'undefined') {
            zoom = 10;
        }
        if (typeof heading == 'undefined') {
            heading = 0;
        }
        map.flyTo({
            center: [
                longitude,
                latitude
            ],
            speed: 1,
            zoom: zoom,
            heading: heading,
            pitch: 0
        });
    };

    map.addMarker = function (latitude, longitude) {
        var el = document.createElement("div");

        el.className = "map-marker";
        new maplibregl.Marker(el).setLngLat([longitude, latitude]).addTo(map);
    };

    map.removeMarkers = function () {
        var oldmarkers = document.getElementsByClassName("map-marker");
        if (oldmarkers.length > 0) {
            markerparent = oldmarkers[0].parentNode;
            while (oldmarkers.length > 0) {
                markerparent.removeChild(oldmarkers[0]);
            }
        }
    }

    return map;
}