/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */

var platform_type = "";

var platform_theme = "md";

var app_version = "unknown";

var nw_tray = null;

/**
 * If true and animations are set to "auto", animations should be disabled.
 * @type Boolean
 */
var auto_disable_animations = false;

var cordovaInAppBrowserRef = null;

var openBrowser = function (url) {
    window.open(url);
};

var closeBrowser = function () {
    // stub
};

var openExternalBrowser = function (url) {
    window.open(url);
};

var doHapticFeedback = function () {
    console.log("Haptics not enabled.");
};

var appTheme = "light";

var getLocation = function (success, error) {
    if ("geolocation" in navigator) {
        navigator.geolocation.getCurrentPosition(function (position) {
            success(position);
        }, function (err) {
            if (typeof error == "function") {
                error(err.message);
            }
        }, {
            enableHighAccuracy: true,
            timeout: 5000,
            maximumAge: 0
        });
    } else {
        if (typeof error == "function") {
            error("Location is unavailable.");
        }
    }
};

var openGeoLink = function (href) {
    if (platform_type == "cordova") {
        if (cordova.platformId == "ios") {
            window.open(href.replace("geo:", "http://maps.apple.com/?q="), "_system");
        } else if (cordova.platformId == "android") {
            window.open(href.replace("geo:", "geo:0,0?q="), "_system");
        } else {
            window.open(href, "_system");
        }
    } else if (platform_type == "nw") {
        require('nw.gui').Shell.openExternal(href);
    } else {
        window.open(href, "_blank");
    }
};

var copyToClipboard = function (text, callback) {
    navigator.clipboard.writeText(text).then(() => {
        if (typeof callback == "function") {
            callback();
        }
    });
};


function initCordova() {
    platform_type = "cordova";

    // Handle back button to close things
    document.addEventListener("backbutton", handleBackButton, false);
    document.addEventListener("deviceready", function () {
        // Make sure the status bar color is set properly
        applyColorTheme();

        if (typeof device != "undefined" && device.platform == "Android") {
            doHapticFeedback = function () {
                window.plugins.deviceFeedback.acoustic();
            }
        }

        cordova.plugins.ThemeDetection.isAvailable(function (resp) {
            if (resp.value == true) {
                cordova.plugins.ThemeDetection.isDarkModeEnabled(function (resp) {
                    if (resp.value == true) {
                        appTheme = "dark";
                    } else {
                        appTheme = "light";
                    }
                    applyColorTheme();
                }, function (err) {});
            }
        }, function (err) {});

        window.htmlopen = window.open;
        window.open = cordova.InAppBrowser.open;

        openBrowser = function (url, options, onclose, onmessage) {
            if (typeof options == "undefined") {
                options = "location=yes";
            }
            cordovaInAppBrowserRef = cordova.InAppBrowser.open(url, "_blank", options);
            if (typeof onclose == "function") {
                try {
                    cordovaInAppBrowserRef.removeEventListener("exit");
                } catch (ex) {
                }
                cordovaInAppBrowserRef.addEventListener("exit", onclose);
            }
            if (typeof onmessage == "function") {
                try {
                    cordovaInAppBrowserRef.removeEventListener("message");
                } catch (ex) {
                }
                cordovaInAppBrowserRef.addEventListener("message", onmessage);
            }
        }

        closeBrowser = function () {
            if (typeof cordovaInAppBrowserRef != null) {
                cordovaInAppBrowserRef.close();
            }
        }

        openExternalBrowser = function (url) {
            window.open(url, '_system', '');
        }

        IonicDeeplink.onDeepLink(function (link) {
            if (link.host != "fixphrase.com") {
                return;
            }
            // Wait a bit so the home page has time to load first.
            setTimeout(function () {
                if (link.fragment) {
                    var hash = link.fragment;
                    if (/^-?[0-9]{1,2}\.?[0-9]*,-?[0-9]{1,3}\.?[0-9]*$/.test(hash)) {
                        var lat = hash.split(",")[0];
                        var lon = hash.split(",")[1];
                        lat = (Math.round(lat * 10000) / 10000);
                        lon = (Math.round(lon * 10000) / 10000);
                        lookupAndShowCoords(lat, lon);
                    } else if (/^[a-z]+\-[a-z]+\-?[a-z]+?\-?[a-z]+?$/.test(hash)) {
                        var words = hash.replaceAll("-", " ");
                        dolookup(words);
                        $("#wordbox").val(words);
                    } else if (/^[a-z]+\ [a-z]+\ ?[a-z]+?\ ?[a-z]+?$/.test(decodeURI(hash))) {
                        var words = decodeURI(hash);
                        dolookup(words);
                    }
                }
            }, 1000);
        });
    }, false);

    // Handle geo: urls
    $("body").on("click", "a[href^='geo:']", function (evt) {
        openGeoLink($(this).attr("href"));
        evt.preventDefault();
    });

    copyToClipboard = function (text, callback) {
        cordova.plugins.clipboard.copy(text, function () {
            if (typeof callback == "function") {
                callback();
            }
        });
    }
}

function initNW() {
    platform_type = "nw";
    platform_theme = "md";
    openBrowser = function (url) {
        nw.Window.open(url, {
            id: url
        }, function (browserwin) {
            // Add menubar so the user can navigate around if they click a link
            var browsermenu = new nw.Menu({type: 'menubar'});
            browsermenu.append(new nw.MenuItem({
                label: "Back",
                click: function () {
                    browserwin.window.history.back();
                }
            }));
            browsermenu.append(new nw.MenuItem({
                label: "Forward",
                click: function () {
                    browserwin.window.history.forward();
                }
            }));
            browsermenu.append(new nw.MenuItem({
                label: "Home",
                click: function () {
                    browserwin.window.location.href = url;
                }
            }));
            browserwin.menu = browsermenu;
        });
    }

    openExternalBrowser = function (url) {
        require('nw.gui').Shell.openExternal(url);
    }

    // Handle geo: urls
    $("body").on("click", "a[href^='geo:']", function (evt) {
        openGeoLink($(this).attr("href"));
        evt.preventDefault();
    });

    // automatic theme, default light
    if (typeof Framework7.device.prefersColorScheme() !== 'undefined' && Framework7.device.prefersColorScheme() == "dark") {
        appTheme = "dark";
    } else {
        appTheme = "light";
    }
    applyColorTheme();
}

function initBrowser() {
    platform_type = "browser";
    platform_theme = "md";
    openBrowser = function (url) {
        window.open(url);
    }

    openExternalBrowser = function (url) {
        window.open(url);
    }

    $("body").on("click", "a[href^='geo:']", function (evt) {
        openGeoLink($(this).attr("href"));
        evt.preventDefault();
    });

    // automatic theme, default light
    if (typeof Framework7.device.prefersColorScheme() !== 'undefined' && Framework7.device.prefersColorScheme() == "dark") {
        appTheme = "dark";
    } else {
        appTheme = "light";
    }
    applyColorTheme();
}

function initPlatform() {
    if (typeof cordova !== 'undefined') {
        initCordova();
    } else if (typeof nw !== 'undefined') {
        initNW();
    } else {
        initBrowser();
    }

    $.getJSON("package.json", function (data) {
        app_version = data.version;
    });
}