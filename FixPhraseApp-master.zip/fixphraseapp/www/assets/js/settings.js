/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */


$('.item-link[data-setting=apptheme] select').on("change", function () {
    setStorage("apptheme", $('.item-link[data-setting=apptheme] select').val());

    applyColorTheme();
});

$('.item-link[data-setting=animation] select').on("change", function () {
    setStorage("animation", $('.item-link[data-setting=animation] select').val());

    if (getStorage("animation") != "auto") {
        setAnimations();
    }
    if (getStorage("animation") == "auto") {
        toggleAnimations(auto_disable_animations == false);
    }
});

$('.item-link[data-setting=mapsource] select').on("change", function () {
    setStorage("mapsource", $('.item-link[data-setting=mapsource] select').val());
});

$('.item-link[data-setting=units] select').on("change", function () {
    setStorage("units", $('.item-link[data-setting=units] select').val());
});

$('.item-link[data-setting=trackzoom] select').on("change", function () {
    setStorage("trackzoom", $('.item-link[data-setting=trackzoom] select').val());
});

$('.item-content[data-setting=mapscale] .toggle input').on("change", function () {
    var checked = $(this).prop('checked');
    setStorage("mapscale", checked ? "true" : "false");
});