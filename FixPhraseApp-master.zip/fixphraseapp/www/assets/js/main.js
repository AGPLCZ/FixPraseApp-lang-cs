/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

var $$ = Dom7;

// Detect platform and run platform-specific setup code
// for Cordova, NW.js, or the browser
initPlatform();

var app = new Framework7({
    root: "#app",
    name: SETTINGS.branding.apptitle,
    id: "com.fixphrase.app",
    theme: "auto",
    card: {
        swipeToClose: false
    },
    popup: {
        backdrop: true
    },
    popover: {
        backdrop: true
    },
    sheet: {
        backdrop: false
    },
    init: false,
    initOnDeviceReady: false,
    routes: routes
});

var mainView = app.views.create('#view-main', {
    url: "/",
    animate: true,
    loadInitialPage: false
});

var router = mainView.router;

function restartApplication() {
    window.location = "index.html";
}


router.on("pageInit", function (pagedata) {
    pagedata.$el.find('script').each(function (el) {
        if ($$(this).attr('src')) {
            var s = document.createElement('script');
            s.src = $$(this).attr('src');
            $$('head').append(s);
        } else {
            eval($$(this).text());
        }
    });
    // Stop text selection from popping a system toolbar even after changing pages
    if (window.getSelection) {
        window.getSelection().removeAllRanges();
    } else if (document.selection) {
        document.selection.empty();
    }
});

/**
 * Perform back button behavior.
 * Call this function whenever the equivalent to the Android back button is pressed.
 * @returns {undefined}
 */
function handleBackButton() {
    // Close sheet if it's open
    if ($(".sheet-modal").hasClass("modal-in")) {
        app.sheet.close();
    } else if ($(".popup").hasClass("modal-in")) {
        app.popup.close();
    } else if ($(".searchbar-enabled")[0]) {
        app.searchbar.disable();
    } else {
        router.back({force: true, ignoreCache: true});
    }
    // Stop text selection from popping a system toolbar even after changing pages
    if (window.getSelection) {
        window.getSelection().removeAllRanges();
    } else if (document.selection) {
        document.selection.empty();
    }
}

$(document).on("mousedown", ".hapticbtn,.input-clear-button,.button,.link", function () {
    doHapticFeedback();
});

$(document).keyup(function (e) {
    if (e.key === "Escape" || e.keyCode == 27) {
        handleBackButton();
    }
});

router.on("routeChange", function (newRoute) {
    console.log("Info", "Navigating to ", newRoute.path);
});

function setAppTheme(theme) {
    if (theme == "light") {
        $("body").removeClass("theme-dark");
        if (platform_type == "cordova" && typeof StatusBar !== 'undefined') {
            StatusBar.styleDefault();
            if (device.platform == "Android") {
                StatusBar.backgroundColorByHexString("#ffffff");
            } else {
                StatusBar.backgroundColorByHexString("#ffffff");
            }
        }
    } else if (theme == "dark") {
        $("body").addClass("theme-dark");
        if (platform_type == "cordova" && typeof StatusBar !== 'undefined') {
            StatusBar.styleLightContent();
            StatusBar.backgroundColorByHexString("#000000");
        }
    }
}

function applyColorTheme() {
    if (getStorage("apptheme") == "dark") {
        setAppTheme("dark");
    } else if (getStorage("apptheme") == "light") {
        setAppTheme("light");
    } else {
        setAppTheme(appTheme);
    }
}

/**
 * Turn animations on or off.
 * @param {boolean} on true for on, false for off.
 * @returns {undefined}
 */
function toggleAnimations(on) {
    if (on) {
        $("#app").removeClass("no-animation");
    } else {
        $("#app").addClass("no-animation");
    }
    mainView.params.animate = on;
}

/**
 * Turn animations on or off while considering user preferences.
 * @param boolean enabled true to enable, false to disable, undefined to use animation=on/off setting.
 * @returns {undefined}
 */
function setAnimations(enabled) {
    if (getStorage("animation") == null) {
        setStorage("animation", "auto");
    }
    if (typeof enabled !== "undefined") {
        toggleAnimations(enabled == true);
        return;
    }
    if (getStorage("animation") == "off") {
        toggleAnimations(false);
    } else if (getStorage("animation") == "on") {
        toggleAnimations(true);
    }
}

applyColorTheme();
setAnimations();

app.init();

$("body").on("click", ".copyonclick", function () {
    var copyitem = $(this);
    var copytext = copyitem.text();
    if (copytext == "Copied!") {
        // prevent copying copied text if double-clicked
        return;
    }
    copyToClipboard(copytext, function () {
        copyitem.text("Copied!");
        setTimeout(function () {
            copyitem.text(copytext);
        }, 1000);
    });
});

router.navigate("/home");

document.title = SETTINGS.branding.apptitle;