/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */


/**
 * Save something to persistent storage.
 * @param {string} key
 * @param {string} value non-string values are converted to strings.
 * @returns {undefined}
 */
function setStorage(key, value) {
    localStorage.setItem(key, value);
}

/**
 * Get an item from persistent storage.
 * @param {type} key
 * @returns {DOMString}
 */
function getStorage(key) {
    return localStorage.getItem(key);
}

function removeFromStorage(key) {
    localStorage.removeItem(key);
}

/**
 * Check if an item is in the persistent storage.
 * @param {string} key
 * @returns {Boolean}
 */
function inStorage(key) {
    return localStorage.getItem(key) != null;
}

/**
 * Get all item from persistent storage.
 * @returns {Array} [{key: "", value: ""},...]
 */
function getAllStorage() {
    var all = [];
    for (var key in localStorage) {
        if (localStorage.hasOwnProperty(key)) {
            all.push({
                key: key,
                value: getStorage(key)
            });
        }
    }
    return all;
}