/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */

$("body").on("submit", "#wordbox-searchbar", function (e) {
    e.preventDefault();
    dolookup($("#wordbox").val());
    return false;
});

function dolookup(words) {
    try {
        words = words.trim().toLowerCase().replace(/\s+/g, ' ');

        if (!/^[a-z ]+?$/i.test(words)) {
            // Not a FixPhrase, run a search
            $.getJSON(SETTINGS.apis.lookup, {
                search: words
            }, function (resp) {
                if (resp.status == "OK") {
                    lookupAndShowCoords(resp.coords[0], resp.coords[1]);
                } else {
                    alert("Error: " + resp.msg);
                }
            });
            return;
        }

        var coords = FixPhrase.decode(words);

        showLocationPopup(coords[0], coords[1], coords[3], coords[2]);
        $("#wordbox").val(coords[3]);

        var zoomlevel = 18;
        switch (coords[2]) {
            case 0.1:
                zoomlevel = 10;
                break;
            case 0.01:
                zoomlevel = 13;
                break;
        }
        map.animateMapIn(coords[0], coords[1], zoomlevel);
    } catch (e) {
        app.dialog.alert(e, "Error");
    }
}

function openLocationActionDialog(latitude, longitude, words) {
    app.actions.create({
        buttons: [
            [
                {
                    text: words,
                    label: true,
                    bold: true
                }
            ],
            [
                {
                    text: "<i class='far fa-share'></i> &nbsp; Share",
                    label: true
                },
                {
                    text: "FixPhrase",
                    onClick: function () {
                        window.plugins.socialsharing.shareWithOptions({
                            message: words
                        });
                    }
                },
                {
                    text: "Link",
                    onClick: function () {
                        window.plugins.socialsharing.shareWithOptions({
                            url: "https://fixphrase.com/#" + words.replaceAll(" ", "-")
                        });
                    }
                },
                {
                    text: "Coordinates",
                    onClick: function () {
                        window.plugins.socialsharing.shareWithOptions({
                            message: latitude + ", " + longitude
                        });
                    }
                }
            ],
            [
                {
                    text: "<i class='far fa-copy'></i> &nbsp; Copy",
                    label: true
                },
                {
                    text: "FixPhrase",
                    onClick: function () {
                        copyToClipboard(words, function () {
                            app.toast.show({text: "Copied!", closeTimeout: 3000});
                        });
                    }
                },
                {
                    text: "Link",
                    onClick: function () {
                        copyToClipboard("https://fixphrase.com/#" + words.replaceAll(" ", "-"), function () {
                            app.toast.show({text: "Copied!", closeTimeout: 3000});
                        });
                    }
                },
                {
                    text: "Coordinates",
                    onClick: function () {
                        copyToClipboard(latitude + ", " + longitude, function () {
                            app.toast.show({text: "Copied!", closeTimeout: 3000});
                        });
                    }
                }
            ],
            [
                {
                    text: "Open in default maps app",
                    onClick: function () {
                        openGeoLink("geo:" + latitude + "," + longitude);
                    }
                }
            ],
            [
                {
                    text: "Cancel"
                }
            ]
        ]
    }).open();
}