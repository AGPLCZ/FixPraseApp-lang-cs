/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */

var SETTINGS = {
    apis: {
        lookup: "https://fixphrase.com/lookup.php"
    },
    branding: {
        apptitle: "FixPhrase",
        company: "Netsyms Technologies",
        website: "https://fixphrase.com"
    },
    maptileurls: {
        light: {
            json: "https://maps.netsyms.net/styles/osm-liberty/style.json",
            name: "Light",
            bgcolor: "#EFEFEF"
        },
        dark: {
            json: "https://maps.netsyms.net/styles/osm-liberty-dark/style.json",
            name: "Dark",
            bgcolor: "#1A1A1A"
        },
        terrain: {
            json: "https://maps.netsyms.net/styles/klokantech-terrain/style.json",
            name: "Terrain",
            bgcolor: "#EDF5F3"
        },
        satellite: {
            json: "https://api.maptiler.com/maps/hybrid/style.json?key=AYuZSCBTy6vqGBlP0PwL",
            name: "Satellite",
            bgcolor: "#1A1A1A"
        },
        oledblack: {
            json: "https://maps.netsyms.net/styles/oled-black/style.json",
            name: "Black",
            bgcolor: "#000000"
        }
    }
}
