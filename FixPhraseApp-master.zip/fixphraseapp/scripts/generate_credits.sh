#!/bin/bash

echo "Generating credits files..."

cd www
yarn licenses generate-disclaimer > ../license-credits.md
cd ..
yarn licenses generate-disclaimer >> license-credits.md

cp www/pages/credits.template.html www/pages/credits.html
sed -i -e "/{{credits}}/r license-credits.md" -e "/{{credits}}/d" www/pages/credits.html
