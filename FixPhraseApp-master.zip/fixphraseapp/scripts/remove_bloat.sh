#!/bin/bash
# This script removes some stuff in `www/node_modules` that the app doesn't need to run.
# It makes the build under 6MB, and prevents zip64-related crashes.

echo "Removing bloat in node_modules..."

set -e

DIR="$(pwd)/www/node_modules"

cd "$DIR"
rm -rf {buffer-from,concat-stream,csscolorparser,dom7,earcut,geojson-vt,gl-matrix}
rm -rf {grid-index,htm,ieee754,inherits,kdbush,@mapbox,minimist,murmurhash-js,path-to-regexp,pbf}
rm -rf {potpack,protocol-buffers-schema,quickselect,readable-stream,resolve-protobuf-schema,rw}
rm -rf {safe-buffer,skeleton-elements,ssr-window,string_decoder,supercluster,swiper,text-encoding,tinyqueue}
rm -rf {ts-custom-error,typedarray,util-deprecate,vt-pbf}

# Make npm stop complaining that these don't exist by actually removing them
rm -rf .bin/*
cd "$DIR"

cd @fortawesome/fontawesome-pro
rm -rf {js,less,metadata,scss,sprites,svgs}
find css -type f -not -name 'all.min.css' -delete
find webfonts -type f -not -name '*.woff2' -delete
find webfonts -type f -name "fa-brands-400.*" -delete
find . -type f -name '*.tgz' -delete # for some reason it's packaging an 18MB tarball sometimes
cd "$DIR"

cd framework7
rm -rf {bundle,cjs,components,core,esm,less,lite,lite-bundle,modules,types}
find . -type f -not -name 'framework7-bundle.min.js' -not -name 'framework7-bundle.min.css' -not -name 'LICENSE' -not -name 'package.json' -delete
cd "$DIR"

cd template7
rm -rf src
find . -type f -not -name "LICENSE" -not -name "package.json" -not -name "template7.min.js" -delete
cd "$DIR"

cd jquery
rm -rf src
rm -rf external
find dist -type f -not -name 'jquery.min.js' -delete
cd "$DIR"

cd maplibre-gl
rm -rf {build,flow-typed,src}
find . -name "CHANGELOG.md" -delete
find dist -type f -not -name 'maplibre-gl.css' -not -name 'maplibre-gl.js' -delete
rm -rf dist/style-spec
cd "$DIR"

echo "Cleanup finished"
