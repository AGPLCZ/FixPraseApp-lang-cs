#!/bin/bash

echo "Installing node modules in www/..."

cd www
rm -rf node_modules
npm install
cd ..
