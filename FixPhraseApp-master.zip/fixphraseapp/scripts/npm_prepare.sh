#!/bin/sh

./scripts/www_npm_install.sh
./scripts/remove_bloat.sh
./scripts/generate_credits.sh